var __ext = globalThis.browser ?? globalThis.chrome;
"use strict";
(() => {
  // ../packages/importer/src/util.ts
  var CLASS_SLUGS = ["artificer", "barbarian", "bard", "cleric", "druid", "fighter", "monk", "paladin", "ranger", "rogue", "sorcerer", "warlock", "wizard"];
  var SRD_CLASS_SLUGS = CLASS_SLUGS.filter((c) => c !== "artificer");

  // ../packages/importer/src/detect.ts
  var WIKI_HOSTS = {
    "dnd2024.wikidot.com": { wiki: "wikidot", ruleset: "2024", label: "dnd2024.wikidot.com (2024 rules)" },
    "dnd5e.wikidot.com": { wiki: "wikidot", ruleset: "2014", label: "dnd5e.wikidot.com (2014 rules)" },
    "www.dandwiki.com": { wiki: "dandwiki", ruleset: "2014", label: "dandwiki.com (homebrew)" }
  };
  function normalizeUrl(input) {
    const u = new URL(input.trim());
    if (u.hostname === "dandwiki.com") u.hostname = "www.dandwiki.com";
    if (u.hostname in WIKI_HOSTS) u.protocol = "https:";
    u.hash = "";
    return u.toString();
  }
  var WIKIDOT_PAGES = {
    spell: "spell",
    feat: "feat",
    species: "species",
    lineage: "species",
    "magic-item": "item",
    "wondrous-items": "item"
  };
  var WIKIDOT_INDEXES = {
    spells: "spell-index",
    lineage: "species-index",
    "wondrous-items": "item-index"
  };
  var DANDWIKI_TYPES = {
    Spell: "spell",
    Subclass: "subclass",
    Feat: "feat",
    Race: "species",
    Equipment: "item",
    "Magic Item": "item"
  };
  function detectPage(input) {
    let url;
    try {
      url = normalizeUrl(input);
    } catch {
      return { wiki: null, kind: "unknown", url: input, path: [] };
    }
    const u = new URL(url);
    const host = WIKI_HOSTS[u.hostname];
    if (!host) return { wiki: null, kind: "unknown", url, path: [] };
    const base = { wiki: host.wiki, url, ruleset: host.ruleset };
    if (host.wiki === "wikidot") {
      const raw = decodeURIComponent(u.pathname.replace(/^\/+/, ""));
      const path2 = raw.split(":").filter(Boolean);
      const [first, second] = path2;
      if (!first) return { ...base, kind: "feat-index", path: path2 };
      if (second === "all" && first === "feat") return { ...base, kind: "feat-index", path: path2 };
      if (second === "all" && first === "species") return { ...base, kind: "species-index", path: path2 };
      if (second === "all" && first === "magic-item") return { ...base, kind: "item-index", path: path2 };
      if (first === "spells") return { ...base, kind: "spell-index", path: path2 };
      if (!second && WIKIDOT_INDEXES[first]) return { ...base, kind: WIKIDOT_INDEXES[first], path: path2 };
      if (second && path2.length === 2 && WIKIDOT_PAGES[first]) return { ...base, kind: WIKIDOT_PAGES[first], path: path2 };
      if (CLASS_SLUGS.includes(first)) {
        if (path2.length === 1) return { ...base, kind: "class-index", path: path2 };
        if (path2.length === 2 && second !== "spell-list") return { ...base, kind: "subclass", path: path2 };
      }
      return { ...base, kind: "unknown", path: path2 };
    }
    const title = decodeURIComponent(u.pathname.replace(/^\/wiki\//, "")).replace(/_/g, " ");
    const path = [title];
    const typed = /\(5e ([^)]+)\)\s*$/.exec(title);
    if (typed && DANDWIKI_TYPES[typed[1]]) return { ...base, kind: DANDWIKI_TYPES[typed[1]], path };
    if (/^5e (Cantrips|\d(st|nd|rd|th) Level Spells|\w+ Spells|All Spells)$/.test(title)) return { ...base, kind: "spell-index", path };
    if (title === "5e Subclasses") return { ...base, kind: "class-index", path };
    if (title === "5e Feats") return { ...base, kind: "feat-index", path };
    if (/5e Races$/.test(title)) return { ...base, kind: "species-index", path };
    if (/^5e (Magic Items|Equipment|.* Magic Items)$/.test(title)) return { ...base, kind: "item-index", path };
    return { ...base, kind: "unknown", path };
  }

  // ../packages/importer/src/vtt.ts
  var DEFAULT_VTT_SETTINGS = { whisper: false, critRule: "double-dice" };

  // src/settings.ts
  var DEFAULTS = {
    appUrl: "http://localhost:5173/",
    foundryUrls: ["https://dnd.mindgame-quiz.de/"],
    vtt: DEFAULT_VTT_SETTINGS
  };
  async function getSettings() {
    const stored = await __ext.storage.sync.get(DEFAULTS);
    return { ...DEFAULTS, ...stored, vtt: { ...DEFAULT_VTT_SETTINGS, ...stored.vtt } };
  }
  async function saveSettings(s) {
    await __ext.storage.sync.set(s);
  }
  function originPattern(url) {
    const u = new URL(url);
    return `${u.protocol}//${u.hostname}/*`;
  }

  // src/popup.ts
  var $ = (id) => document.getElementById(id);
  async function init() {
    const status = await __ext.runtime.sendMessage({ kind: "status" });
    const manifestVersion = __ext.runtime.getManifest().version;
    if (status.version !== manifestVersion) {
      const warn = document.createElement("p");
      warn.className = "warn";
      warn.textContent = `The extension background still runs v${status.version} (installed: v${manifestVersion}). Click \u201CReload\u201D on the extension card in edge://extensions \u2013 if that doesn\u2019t help, restart the browser.`;
      $("status").after(warn);
    }
    $("status").innerHTML = status.appTabs ? `<span class="ok">\u25CF</span> Connected to ${status.appTabs} app tab${status.appTabs > 1 ? "s" : ""} \xB7 v${status.version}` : `\u25CB No app tab open \xB7 v${status.version}<br><span class="muted">Open Charbogen in a tab of <b>this</b> browser (the desktop icon opens Microsoft Edge), then reload it.</span>`;
    const manifest = __ext.runtime.getManifest();
    const wanted = [.../* @__PURE__ */ new Set([...manifest.content_scripts?.flatMap((c) => c.matches ?? []) ?? [], ...manifest.host_permissions ?? []])];
    const missingOrigins = [];
    for (const o of wanted) if (!await __ext.permissions.contains({ origins: [o] })) missingOrigins.push(o);
    if (missingOrigins.length) {
      const box2 = document.createElement("div");
      box2.innerHTML = `<p class="warn">The extension may not access the Charbogen app yet.</p>`;
      const btn = document.createElement("button");
      btn.className = "primary";
      btn.textContent = "Allow access to Charbogen";
      btn.addEventListener("click", async () => {
        const ok = await __ext.permissions.request({ origins: missingOrigins });
        box2.innerHTML = ok ? `<p class="ok">Access allowed \u2013 reload the Charbogen tab (F5).</p>` : `<p class="warn">Not allowed \u2013 Charbogen can't receive rolls.</p>`;
      });
      box2.append(btn);
      $("status").after(box2);
    }
    const box = $("targets");
    box.textContent = "";
    for (const t of status.vtt) {
      const label = document.createElement("label");
      const input = document.createElement("input");
      input.type = "radio";
      input.name = "target";
      input.checked = t.tabId === status.selected;
      input.addEventListener("change", () => void __ext.runtime.sendMessage({ kind: "select-vtt", tabId: t.tabId }));
      label.append(input, `${t.vtt === "foundry" ? "Foundry" : "Roll20"} \u2013 ${t.title}`);
      box.append(label);
    }
    $("noTarget").hidden = status.vtt.length > 0;
    const missing = status.foundry.filter((f) => !f.granted);
    if (missing.length) {
      $("foundryGrant").hidden = false;
      $("foundryHost").textContent = missing.map((f) => new URL(f.url).hostname).join(", ");
      $("grant").addEventListener("click", async () => {
        const ok = await __ext.permissions.request({ origins: missing.map((f) => originPattern(f.url)) });
        if (ok) {
          await __ext.runtime.sendMessage({ kind: "register-foundry" });
          $("foundryGrant").hidden = true;
          $("result").textContent = "Foundry enabled \u2013 reload the Foundry tab.";
        }
      });
    }
    const settings = await getSettings();
    const whisper = $("whisper");
    const critRule = $("critRule");
    whisper.checked = settings.vtt.whisper;
    critRule.value = settings.vtt.critRule;
    const store = () => void saveSettings({ vtt: { whisper: whisper.checked, critRule: critRule.value } });
    whisper.addEventListener("change", store);
    critRule.addEventListener("change", store);
    const [tab] = await __ext.tabs.query({ active: true, currentWindow: true });
    const info = tab?.url ? detectPage(tab.url) : void 0;
    if (info?.wiki) {
      $("wiki").hidden = false;
      $("page").textContent = `${info.kind === "unknown" ? "Page" : info.kind}: ${decodeURIComponent(new URL(info.url).pathname)}`;
      $("import").addEventListener("click", async () => {
        $("import").disabled = true;
        const res = await __ext.runtime.sendMessage({ kind: "import-url", url: info.url });
        $("result").textContent = res.error ? `Error: ${res.error}` : res.delivered ? "Sent to the app." : "Opened the app.";
        if (!res.error) setTimeout(() => window.close(), 600);
      });
    }
    if (tab?.id !== void 0 && /^https?:/.test(tab.url ?? "") && !/^https?:\/\/(localhost|127\.0\.0\.1)/.test(tab.url ?? "")) {
      try {
        const res = await __ext.scripting.executeScript({ target: { tabId: tab.id }, func: pageImages });
        const list = res[0]?.result ?? [];
        $("images").hidden = false;
        const grid = $("imageGrid");
        if (!list.length) $("imagesHint").textContent = "No large images on this page.";
        for (const img of list) {
          const b = document.createElement("button");
          b.title = "Use this image in Charbogen";
          const el = document.createElement("img");
          el.src = img.src;
          el.referrerPolicy = "no-referrer";
          b.append(el);
          b.addEventListener("click", async () => {
            const r = await __ext.runtime.sendMessage({ kind: "send-image", url: img.src, pageUrl: tab.url, pageTitle: tab.title });
            $("result").textContent = r.error === "unknown request" ? "The extension background is outdated \u2013 reload the extension in edge://extensions or restart the browser." : r.error ? `Error: ${r.error}` : r.delivered ? "Sent to Charbogen \u2713" : "Saved \u2013 open the app and a picture field to use it.";
            if (r.delivered) setTimeout(() => window.close(), 700);
          });
          grid.append(b);
        }
      } catch {
      }
    }
    $("options").addEventListener("click", (e) => {
      e.preventDefault();
      void __ext.runtime.openOptionsPage();
    });
  }
  function pageImages() {
    const vh = window.innerHeight;
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const img of Array.from(document.images)) {
      const src = img.currentSrc || img.src;
      if (!src || seen.has(src) || src.startsWith("data:image/gif") || src.startsWith("data:image/svg")) continue;
      const r = img.getBoundingClientRect();
      if (r.width < 90 || r.height < 90 || img.naturalWidth < 150) continue;
      seen.add(src);
      const visible = r.bottom > 0 && r.top < vh;
      out.push({ src, score: r.width * r.height * (visible ? 4 : 1) });
    }
    return out.sort((a, b) => b.score - a.score).slice(0, 18).map(({ src }) => ({ src }));
  }
  init().catch((e) => {
    const el = document.getElementById("status");
    if (el) {
      el.className = "warn";
      el.textContent = `Could not start: ${e instanceof Error ? e.message : String(e)}`;
    }
    console.error(e);
  });
})();

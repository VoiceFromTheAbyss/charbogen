var __ext = globalThis.browser ?? globalThis.chrome;
"use strict";
(() => {
  // ../packages/importer/src/protocol.ts
  var NS = "charbogen";
  var PROTOCOL_VERSION = 1;
  function isEnvelope(data, dir) {
    return !!data && typeof data === "object" && data.ns === NS && data.v === PROTOCOL_VERSION && data.dir === dir;
  }

  // src/bridge.ts
  var VERSION = __ext.runtime.getManifest().version;
  var port;
  function toPage(kind, payload, id = crypto.randomUUID()) {
    const msg = { ns: NS, v: PROTOCOL_VERSION, id, dir: "from-ext", kind, payload };
    window.postMessage(msg, location.origin);
  }
  function connect() {
    if (port) return port;
    const p = __ext.runtime.connect({ name: "charbogen-app" });
    p.onMessage.addListener((msg) => toPage(msg.kind, msg.payload, msg.id));
    p.onDisconnect.addListener(() => {
      port = void 0;
      setTimeout(() => {
        try {
          connect();
        } catch {
        }
      }, 500);
    });
    port = p;
    return p;
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin || !isEnvelope(event.data, "to-ext")) return;
    const msg = event.data;
    try {
      if (msg.kind === "hello") connect().postMessage({ id: msg.id, kind: "hello" });
      else if (msg.kind === "vtt-status") connect().postMessage({ id: msg.id, kind: "vtt-status" });
      else if (msg.kind === "roll") connect().postMessage({ id: msg.id, kind: "roll", roll: msg.payload });
      else if (msg.kind === "fetch") {
        const url = msg.payload.url;
        if (typeof url === "string") connect().postMessage({ id: msg.id, kind: "fetch", url });
      }
    } catch (e) {
      toPage("fetch-result", { url: "", error: `Extension unavailable: ${e.message}`, code: "unavailable" }, msg.id);
    }
  });
  connect();
  toPage("ext-ready", { version: VERSION });
})();

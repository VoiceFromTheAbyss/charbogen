"use strict";
(() => {
  // src/foundry-page.ts
  var PAGE_NS = "charbogen-vtt";
  function esc(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  async function execute(plan) {
    const g = globalThis;
    if (!g.game?.ready) throw new Error("Foundry is not ready \u2013 log in and open the world first.");
    const main = await new g.Roll(plan.main).evaluate();
    let crit = false;
    let fumble = false;
    if (plan.hasD20) {
      const natural = main.dice[0]?.results.find((r) => r.active !== false && !r.discarded)?.result;
      crit = natural !== void 0 && natural >= plan.critThreshold;
      fumble = natural === 1;
    }
    const rolls = [main];
    for (const d of plan.damage) rolls.push(await new g.Roll(crit ? d.crit : d.normal).evaluate());
    const tags = [crit ? '<span style="color:#2e7d32;font-weight:bold">Critical hit!</span>' : "", fumble ? '<span style="color:#c62828;font-weight:bold">Natural 1</span>' : ""].filter(Boolean).join(" ");
    const damage = plan.damage.length ? `<div>${crit ? "Critical damage" : "Damage"}: ${plan.damage.map((d) => esc(d.type || "\u2014")).join(" + ")}</div>` : "";
    const flavor = `<strong>${esc(plan.flavor)}</strong>${tags ? ` ${tags}` : ""}${damage}${plan.description ? `<div style="font-size:0.9em;opacity:0.8">${esc(plan.description)}</div>` : ""}`;
    const data = { speaker: { alias: plan.speaker }, flavor, rolls };
    g.ChatMessage.applyRollMode(data, plan.rollMode);
    await g.ChatMessage.create(data);
  }
  window.addEventListener("message", (ev) => {
    const d = ev.data;
    if (ev.source !== window || d?.ns !== PAGE_NS || d.dir !== "to-page" || !d.id || !d.plan) return;
    const reply = (ok, error) => window.postMessage({ ns: PAGE_NS, dir: "from-page", id: d.id, ok, ...error ? { error } : {} }, location.origin);
    execute(d.plan).then(
      () => reply(true),
      (e) => reply(false, e.message)
    );
  });
})();

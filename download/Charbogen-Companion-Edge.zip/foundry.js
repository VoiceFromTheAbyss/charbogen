"use strict";
(() => {
  // ../packages/importer/src/vtt.ts
  var DICE = /(\d*)d(\d+)/gi;
  function norm(formula) {
    return formula.replace(/−/g, "-").replace(/\s+/g, " ").trim();
  }
  function d20Formula(formula, advantage, vtt, critThreshold = 20) {
    const f = norm(formula);
    if (!/^1d20\b/i.test(f)) return f;
    const keep = advantage === "advantage" ? vtt === "roll20" ? "kh1" : "kh" : advantage === "disadvantage" ? vtt === "roll20" ? "kl1" : "kl" : "";
    const count = keep ? 2 : 1;
    const crit = vtt === "roll20" && critThreshold < 20 ? `cs>${critThreshold}` : "";
    return f.replace(/^1d20\b/i, `${count}d20${keep}${crit}`);
  }
  function damageFormula(formula, vtt, dieMinimum) {
    const f = norm(formula);
    return vtt === "foundry" && dieMinimum ? f.replace(DICE, (_m, n, s) => `${n || 1}d${s}min${dieMinimum}`) : f;
  }
  function critDamageFormula(formula, rule) {
    const f = norm(formula);
    if (rule === "double-dice") return f.replace(DICE, (_m, n, s) => `${Number(n || 1) * 2}d${s}`);
    return f.replace(DICE, (_m, n, s) => `${Number(n || 1) * Number(s)} + ${n || 1}d${s}`);
  }
  var ADV_LABEL = { normal: "", advantage: " (Advantage)", disadvantage: " (Disadvantage)" };
  function cleanText(s) {
    return s.replace(/\}\}/g, "} }").replace(/\[\[/g, "[ [").replace(/\*\*/g, "").replace(/\n+/g, " ").trim();
  }
  function foundryPlan(r, s) {
    const hasD20 = /^1d20/.test(norm(r.formula));
    return {
      main: d20Formula(r.formula, r.advantage, "foundry"),
      hasD20,
      critThreshold: r.critThreshold ?? 20,
      damage: (r.damage ?? []).map((d) => ({
        type: d.type,
        normal: damageFormula(d.formula, "foundry", d.dieMinimum),
        crit: damageFormula(critDamageFormula(d.formula, s.critRule), "foundry", d.dieMinimum)
      })),
      flavor: `${r.name}${ADV_LABEL[r.advantage]}`,
      speaker: r.character,
      rollMode: s.whisper ? "gmroll" : "publicroll",
      description: r.description ? cleanText(r.description).slice(0, 600) : void 0
    };
  }

  // src/vtt-port.ts
  function connectVtt(vtt, onRoll) {
    let port;
    const connect = () => {
      port = chrome.runtime.connect({ name: "charbogen-vtt" });
      port.postMessage({ kind: "hello", vtt, title: document.title });
      port.onMessage.addListener(async (msg) => {
        if (msg.kind !== "roll") return;
        try {
          await onRoll(msg);
          port?.postMessage({ kind: "roll-done", id: msg.id, ok: true });
        } catch (e) {
          port?.postMessage({ kind: "roll-done", id: msg.id, ok: false, error: e.message });
        }
      });
      port.onDisconnect.addListener(() => {
        port = void 0;
        setTimeout(() => {
          try {
            connect();
          } catch {
          }
        }, 1e3);
      });
    };
    connect();
  }

  // src/foundry.ts
  var PAGE_NS = "charbogen-vtt";
  if (/\/game\/?$/.test(location.pathname)) {
    const pending = /* @__PURE__ */ new Map();
    window.addEventListener("message", (ev) => {
      const d = ev.data;
      if (ev.source !== window || d?.ns !== PAGE_NS || d.dir !== "from-page" || !d.id) return;
      pending.get(d.id)?.({ ok: !!d.ok, ...d.error ? { error: d.error } : {} });
      pending.delete(d.id);
    });
    connectVtt("foundry", async ({ id, roll, settings }) => {
      const plan = foundryPlan(roll, settings);
      const result = await new Promise((resolve) => {
        const timer = setTimeout(() => resolve({ ok: false, error: "Foundry page did not answer \u2013 reload the game tab." }), 8e3);
        pending.set(id, (r) => {
          clearTimeout(timer);
          resolve(r);
        });
        window.postMessage({ ns: PAGE_NS, dir: "to-page", id, plan }, location.origin);
      });
      if (!result.ok) throw new Error(result.error ?? "Roll failed in Foundry.");
    });
  }
})();

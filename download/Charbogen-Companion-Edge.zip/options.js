"use strict";
(() => {
  // ../packages/importer/src/vtt.ts
  var DEFAULT_VTT_SETTINGS = { whisper: false, critRule: "double-dice" };

  // src/settings.ts
  var DEFAULTS = {
    appUrl: "http://localhost:5173/",
    foundryUrls: ["https://dnd.mindgame-quiz.de/"],
    vtt: DEFAULT_VTT_SETTINGS
  };
  async function getSettings() {
    const stored = await chrome.storage.sync.get(DEFAULTS);
    return { ...DEFAULTS, ...stored, vtt: { ...DEFAULT_VTT_SETTINGS, ...stored.vtt } };
  }
  async function saveSettings(s) {
    await chrome.storage.sync.set(s);
  }
  function originPattern(url) {
    const u = new URL(url);
    return `${u.protocol}//${u.hostname}/*`;
  }
  function isLocalhost(url) {
    const h = new URL(url).hostname;
    return h === "localhost" || h === "127.0.0.1";
  }

  // src/options.ts
  var appInput = document.getElementById("appUrl");
  var foundryInput = document.getElementById("foundryUrls");
  var saved = document.getElementById("saved");
  void getSettings().then((s) => {
    appInput.value = s.appUrl;
    foundryInput.value = s.foundryUrls.join("\n");
  });
  function parseUrl(raw) {
    try {
      const u = new URL(raw.trim());
      return u.protocol === "https:" || u.protocol === "http:" ? u : null;
    } catch {
      return null;
    }
  }
  document.getElementById("save").addEventListener("click", async () => {
    const app = parseUrl(appInput.value);
    if (!app) {
      saved.textContent = "Please enter a full app address, e.g. https://sheet.example.org/";
      return;
    }
    const lines = foundryInput.value.split("\n").map((l) => l.trim()).filter(Boolean);
    const foundry = lines.map(parseUrl);
    if (foundry.some((u) => !u)) {
      saved.textContent = "One of the Foundry addresses is not a valid URL.";
      return;
    }
    const origins = [...isLocalhost(app.toString()) ? [] : [originPattern(app.toString())], ...foundry.map((u) => originPattern(u.toString()))];
    const granted = origins.length ? await chrome.permissions.request({ origins }) : true;
    await saveSettings({ appUrl: app.toString(), foundryUrls: foundry.map((u) => u.toString()) });
    if (!granted) {
      saved.textContent = "Saved, but access was not granted \u2013 the extension cannot connect to those sites.";
      return;
    }
    const r1 = await chrome.runtime.sendMessage({ kind: "register-app", appUrl: app.toString() });
    const r2 = await chrome.runtime.sendMessage({ kind: "register-foundry" });
    saved.textContent = r1.error || r2.error ? `Error: ${r1.error ?? r2.error}` : "Saved. Reload open app and Foundry tabs.";
  });
})();

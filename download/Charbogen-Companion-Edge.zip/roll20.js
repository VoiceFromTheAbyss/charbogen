"use strict";
(() => {
  // ../packages/importer/src/vtt.ts
  var DICE = /(\d*)d(\d+)/gi;
  function norm(formula) {
    return formula.replace(/−/g, "-").replace(/\s+/g, " ").trim();
  }
  function d20Formula(formula, advantage, vtt, critThreshold = 20) {
    const f = norm(formula);
    if (!/^1d20\b/i.test(f)) return f;
    const keep = advantage === "advantage" ? vtt === "roll20" ? "kh1" : "kh" : advantage === "disadvantage" ? vtt === "roll20" ? "kl1" : "kl" : "";
    const count = keep ? 2 : 1;
    const crit = vtt === "roll20" && critThreshold < 20 ? `cs>${critThreshold}` : "";
    return f.replace(/^1d20\b/i, `${count}d20${keep}${crit}`);
  }
  function damageFormula(formula, vtt, dieMinimum) {
    const f = norm(formula);
    return vtt === "foundry" && dieMinimum ? f.replace(DICE, (_m, n, s) => `${n || 1}d${s}min${dieMinimum}`) : f;
  }
  function critDamageFormula(formula, rule) {
    const f = norm(formula);
    if (rule === "double-dice") return f.replace(DICE, (_m, n, s) => `${Number(n || 1) * 2}d${s}`);
    return f.replace(DICE, (_m, n, s) => `${Number(n || 1) * Number(s)} + ${n || 1}d${s}`);
  }
  var ADV_LABEL = { normal: "", advantage: " (Advantage)", disadvantage: " (Disadvantage)" };
  function cleanText(s) {
    return s.replace(/\}\}/g, "} }").replace(/\[\[/g, "[ [").replace(/\*\*/g, "").replace(/\n+/g, " ").trim();
  }
  function roll20Message(r, s) {
    const parts = [`&{template:default} {{name=${cleanText(`${r.character}: ${r.name}`)}${ADV_LABEL[r.advantage]}}}`];
    const label = r.type === "attack" || r.type === "spell" ? r.damage && !/^1d20/.test(r.formula) ? "Roll" : "Attack" : r.type === "damage" ? "Damage" : r.type === "heal" ? "Healing" : "Roll";
    parts.push(`{{${label}=[[${d20Formula(r.formula, r.advantage, "roll20", r.critThreshold)}]]}}`);
    for (const d of r.damage ?? []) {
      const type = d.type ? ` ${d.type}` : "";
      parts.push(`{{Damage${type}=[[${damageFormula(d.formula, "roll20")}]]}}`);
      if (/^1d20/.test(r.formula)) parts.push(`{{Crit${type}=[[${critDamageFormula(d.formula, s.critRule)}]]}}`);
      if (d.dieMinimum) parts.push(`{{Note=Treat damage dice below ${d.dieMinimum} as ${d.dieMinimum}}}`);
    }
    if (r.description) parts.push(`{{Description=${cleanText(r.description).slice(0, 400)}}}`);
    return `${s.whisper ? "/w gm " : ""}${parts.join(" ")}`;
  }

  // src/vtt-port.ts
  function connectVtt(vtt, onRoll) {
    let port;
    const connect = () => {
      port = chrome.runtime.connect({ name: "charbogen-vtt" });
      port.postMessage({ kind: "hello", vtt, title: document.title });
      port.onMessage.addListener(async (msg) => {
        if (msg.kind !== "roll") return;
        try {
          await onRoll(msg);
          port?.postMessage({ kind: "roll-done", id: msg.id, ok: true });
        } catch (e) {
          port?.postMessage({ kind: "roll-done", id: msg.id, ok: false, error: e.message });
        }
      });
      port.onDisconnect.addListener(() => {
        port = void 0;
        setTimeout(() => {
          try {
            connect();
          } catch {
          }
        }, 1e3);
      });
    };
    connect();
  }

  // src/roll20.ts
  function chatInput() {
    const box = document.getElementById("textchat-input");
    const textarea = box?.querySelector("textarea");
    const send = box?.querySelector("button, .btn");
    if (!textarea || !send) throw new Error("Roll20 chat not found \u2013 is the game open?");
    return { textarea, send };
  }
  function setValue(el, value) {
    Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }
  connectVtt("roll20", async ({ roll, settings }) => {
    const { textarea, send } = chatInput();
    const draft = textarea.value;
    setValue(textarea, roll20Message(roll, settings));
    send.click();
    await new Promise((r) => setTimeout(r, 150));
    if (draft) setValue(textarea, draft);
  });
})();

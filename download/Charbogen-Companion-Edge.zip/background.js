"use strict";
(() => {
  // ../packages/importer/src/fetch.ts
  var ALLOWED_HOSTS = ["dnd2024.wikidot.com", "dnd5e.wikidot.com", "www.dandwiki.com"];
  var AGENT_TOKEN = "Charbogen";
  var PageFetchError = class extends Error {
    constructor(code, message, status) {
      super(message);
      this.code = code;
      this.status = status;
    }
    code;
    status;
  };
  function parseRobots(txt) {
    const groups = [];
    let current;
    let lastWasAgent = false;
    for (const raw of txt.split(/\r?\n/)) {
      const line = raw.replace(/#.*$/, "").trim();
      if (!line) continue;
      const m = /^([A-Za-z-]+)\s*:\s*(.*)$/.exec(line);
      if (!m) continue;
      const key = m[1].toLowerCase();
      const value = m[2].trim();
      if (key === "user-agent") {
        if (!current || !lastWasAgent) {
          current = { agents: [], rules: [] };
          groups.push(current);
        }
        current.agents.push(value.toLowerCase());
        lastWasAgent = true;
      } else if ((key === "allow" || key === "disallow") && current) {
        lastWasAgent = false;
        if (value || key === "allow") current.rules.push({ allow: key === "allow", pattern: value });
      } else {
        lastWasAgent = false;
      }
    }
    return groups;
  }
  function patternToRegex(pattern) {
    const anchored = pattern.endsWith("$");
    const body = (anchored ? pattern.slice(0, -1) : pattern).split("*").map((p) => p.replace(/[.+?^${}()|[\]\\]/g, "\\$&")).join(".*");
    return new RegExp(`^${body}${anchored ? "$" : ""}`);
  }
  function isPathAllowed(groups, agent, pathWithQuery) {
    const a = agent.toLowerCase();
    const specific = groups.filter((g) => g.agents.some((x) => x !== "*" && a.includes(x)));
    const applicable = specific.length ? specific : groups.filter((g) => g.agents.includes("*"));
    let best;
    for (const g of applicable) {
      for (const r of g.rules) {
        if (!r.pattern) continue;
        if (patternToRegex(r.pattern).test(pathWithQuery)) {
          const len = r.pattern.length;
          if (!best || len > best.len || len === best.len && r.allow) best = { allow: r.allow, len };
        }
      }
    }
    return best ? best.allow : true;
  }
  var PoliteFetcher = class {
    constructor(opts) {
      this.opts = opts;
      this.minInterval = opts.minIntervalMs ?? 1e3;
      this.allowed = new Set(opts.allowedHosts ?? ALLOWED_HOSTS);
      this.now = opts.now ?? (() => Date.now());
      this.sleep = opts.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
    }
    opts;
    minInterval;
    allowed;
    robots = /* @__PURE__ */ new Map();
    last = /* @__PURE__ */ new Map();
    chains = /* @__PURE__ */ new Map();
    now;
    sleep;
    /** Prüft den Host und normalisiert auf https. */
    checkUrl(input) {
      let u;
      try {
        u = new URL(input);
      } catch {
        throw new PageFetchError("invalid-url", `Invalid URL: ${input}`);
      }
      if (u.hostname === "dandwiki.com") u.hostname = "www.dandwiki.com";
      if (!this.allowed.has(u.hostname)) throw new PageFetchError("host-not-allowed", `Only ${[...this.allowed].join(", ")} can be fetched.`);
      u.protocol = "https:";
      u.hash = "";
      return u;
    }
    async fetch(input) {
      const u = this.checkUrl(input);
      return this.serial(u.hostname, async () => {
        const groups = await this.robotsFor(u);
        if (!isPathAllowed(groups, AGENT_TOKEN, u.pathname + u.search)) {
          throw new PageFetchError("robots-disallowed", `robots.txt of ${u.hostname} disallows ${u.pathname}.`);
        }
        const res = await this.throttled(u.hostname, () => this.opts.fetchFn(u.toString(), { headers: this.opts.headers, redirect: "follow", credentials: "omit" }));
        if (!res.ok) throw new PageFetchError("http-error", `${u.toString()} answered ${res.status}.`, res.status);
        const html = await res.text();
        return { url: u.toString(), finalUrl: res.url || u.toString(), status: res.status, html, fetchedAt: new Date(this.now()).toISOString() };
      });
    }
    async robotsFor(u) {
      const cached = this.robots.get(u.hostname);
      if (cached && this.now() - cached.at < (this.opts.robotsTtlMs ?? 24 * 36e5)) return cached.groups;
      let groups = [];
      try {
        const res = await this.throttled(u.hostname, () => this.opts.fetchFn(`https://${u.hostname}/robots.txt`, { headers: this.opts.headers, credentials: "omit" }));
        if (res.ok) groups = parseRobots(await res.text());
        else if (res.status >= 500) groups = [{ agents: ["*"], rules: [{ allow: false, pattern: "/" }] }];
      } catch (e) {
        throw new PageFetchError("network", `robots.txt of ${u.hostname} could not be loaded: ${e.message}`);
      }
      this.robots.set(u.hostname, { groups, at: this.now() });
      return groups;
    }
    /** Wartet bis zum Ablauf des Mindestabstands seit der letzten Anfrage an diesen Host. */
    async throttled(host, fn) {
      const wait = (this.last.get(host) ?? -Infinity) + this.minInterval - this.now();
      if (wait > 0) await this.sleep(wait);
      this.last.set(host, this.now());
      try {
        return await fn();
      } catch (e) {
        if (e instanceof PageFetchError) throw e;
        throw new PageFetchError("network", e.message);
      }
    }
    /** Anfragen pro Host strikt nacheinander */
    serial(host, fn) {
      const prev = this.chains.get(host) ?? Promise.resolve();
      const next = prev.then(fn, fn);
      this.chains.set(host, next.catch(() => void 0));
      return next;
    }
  };

  // ../packages/importer/src/vtt.ts
  var DEFAULT_VTT_SETTINGS = { whisper: false, critRule: "double-dice" };

  // src/settings.ts
  var DEFAULTS = {
    appUrl: "http://localhost:5173/",
    foundryUrls: ["https://dnd.mindgame-quiz.de/"],
    vtt: DEFAULT_VTT_SETTINGS
  };
  async function getSettings() {
    const stored = await chrome.storage.sync.get(DEFAULTS);
    return { ...DEFAULTS, ...stored, vtt: { ...DEFAULT_VTT_SETTINGS, ...stored.vtt } };
  }
  function originPattern(url) {
    const u = new URL(url);
    return `${u.protocol}//${u.hostname}/*`;
  }
  function isLocalhost(url) {
    const h = new URL(url).hostname;
    return h === "localhost" || h === "127.0.0.1";
  }
  var BRIDGE_SCRIPT_ID = "charbogen-bridge-custom";
  var FOUNDRY_SCRIPT_IDS = { isolated: "charbogen-foundry", main: "charbogen-foundry-page" };

  // src/background.ts
  var VERSION = chrome.runtime.getManifest().version;
  var fetcher = new PoliteFetcher({ fetchFn: (u, init) => fetch(u, init) });
  var appPorts = /* @__PURE__ */ new Map();
  var vttPorts = /* @__PURE__ */ new Map();
  var pendingRolls = /* @__PURE__ */ new Map();
  async function selectedTarget() {
    const { selectedVttTab } = await chrome.storage.local.get("selectedVttTab");
    if (selectedVttTab !== void 0 && vttPorts.has(selectedVttTab)) return selectedVttTab;
    return vttPorts.size === 1 ? [...vttPorts.keys()][0] : void 0;
  }
  function targets() {
    return [...vttPorts.entries()].map(([tabId, v]) => ({ tabId, vtt: v.vtt, title: v.title }));
  }
  async function sendRoll(roll) {
    const tabId = await selectedTarget();
    if (tabId === void 0) {
      return { delivered: false, error: vttPorts.size ? "Several VTT tabs are open \u2013 choose one in the extension popup." : void 0 };
    }
    const target = vttPorts.get(tabId);
    const { vtt } = await getSettings();
    const id = crypto.randomUUID();
    const result = await new Promise((resolve) => {
      const timer = setTimeout(() => {
        pendingRolls.delete(id);
        resolve({ ok: false, error: `${target.vtt === "foundry" ? "Foundry" : "Roll20"} did not answer.` });
      }, 1e4);
      pendingRolls.set(id, (r) => {
        clearTimeout(timer);
        resolve(r);
      });
      target.port.postMessage({ kind: "roll", id, roll, settings: vtt });
    });
    return { delivered: result.ok, target: target.vtt === "foundry" ? "Foundry" : "Roll20", ...result.error ? { error: result.error } : {} };
  }
  chrome.runtime.onConnect.addListener((port) => {
    const tabId = port.sender?.tab?.id;
    if (tabId === void 0) return;
    if (port.name === "charbogen-vtt") {
      port.onMessage.addListener((msg) => {
        if (msg.kind === "hello") vttPorts.set(tabId, { port, vtt: msg.vtt, title: msg.title });
        if (msg.kind === "roll-done") {
          pendingRolls.get(msg.id)?.({ ok: msg.ok, ...msg.error ? { error: msg.error } : {} });
          pendingRolls.delete(msg.id);
        }
      });
      port.onDisconnect.addListener(() => {
        if (vttPorts.get(tabId)?.port === port) vttPorts.delete(tabId);
      });
      return;
    }
    if (port.name !== "charbogen-app") return;
    appPorts.delete(tabId);
    appPorts.set(tabId, port);
    port.onDisconnect.addListener(() => {
      if (appPorts.get(tabId) === port) appPorts.delete(tabId);
    });
    void deliverPendingImage(port);
    port.onMessage.addListener(async (msg) => {
      if (msg.kind === "hello") {
        port.postMessage({ id: msg.id, kind: "hello-ack", payload: { version: VERSION, features: ["fetch", "roll", "image-pick"] } });
      } else if (msg.kind === "vtt-status") {
        port.postMessage({ id: msg.id, kind: "vtt-status", payload: { targets: targets(), selected: await selectedTarget() } });
      } else if (msg.kind === "roll") {
        port.postMessage({ id: msg.id, kind: "roll-ack", payload: await sendRoll(msg.roll) });
      } else if (msg.kind === "fetch") {
        try {
          const result = await fetcher.fetch(msg.url);
          port.postMessage({ id: msg.id, kind: "fetch-result", payload: result });
        } catch (e) {
          const err = e instanceof PageFetchError ? e : new PageFetchError("network", e.message);
          port.postMessage({ id: msg.id, kind: "fetch-result", payload: { url: msg.url, error: err.message, code: err.code, status: err.status } });
        }
      }
    });
  });
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id || sender.tab) return false;
    void handle(msg).then(sendResponse, (e) => sendResponse({ error: e.message }));
    return true;
  });
  async function handle(msg) {
    if (msg.kind === "status") return { version: VERSION, appTabs: appPorts.size, vtt: targets(), selected: await selectedTarget(), foundry: await foundryState() };
    if (msg.kind === "import-url") return importUrl(msg.url);
    if (msg.kind === "send-image") return sendImage({ url: upgradeImageUrl(msg.url), ...msg.pageUrl ? { pageUrl: msg.pageUrl } : {}, ...msg.pageTitle ? { pageTitle: msg.pageTitle } : {} });
    if (msg.kind === "register-app") return registerApp(msg.appUrl);
    if (msg.kind === "register-foundry") return registerFoundry();
    if (msg.kind === "select-vtt") {
      await chrome.storage.local.set({ selectedVttTab: msg.tabId });
      return { ok: true };
    }
    return { error: "unknown request" };
  }
  var MENU_ID = "charbogen-use-image";
  function createMenu() {
    try {
      chrome.contextMenus.removeAll(() => {
        void chrome.runtime.lastError;
        chrome.contextMenus.create({ id: MENU_ID, title: "Use image in Charbogen", contexts: ["image", "link", "page", "frame"] }, () => void chrome.runtime.lastError);
      });
    } catch (e) {
      console.warn("Charbogen: context menu unavailable", e);
    }
  }
  createMenu();
  chrome.runtime.onInstalled.addListener(createMenu);
  chrome.runtime.onStartup.addListener(createMenu);
  function largestVisibleImage() {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let best = null;
    for (const img of Array.from(document.images)) {
      const r = img.getBoundingClientRect();
      const w = Math.min(r.right, vw) - Math.max(r.left, 0);
      const h = Math.min(r.bottom, vh) - Math.max(r.top, 0);
      if (w < 80 || h < 80) continue;
      const src = img.currentSrc || img.src;
      if (!src || src.startsWith("data:image/gif")) continue;
      if (!best || w * h > best.area) best = { src, area: w * h };
    }
    return best?.src ?? null;
  }
  var upgradeImageUrl = (url) => url.replace(/^(https:\/\/i\.pinimg\.com\/)(?:\d+x|\d+x\d+)\//, "$1736x/");
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId !== MENU_ID) return;
    const meta = { ...info.pageUrl ? { pageUrl: info.pageUrl } : {}, ...tab?.title ? { pageTitle: tab.title } : {} };
    if (info.srcUrl && info.mediaType === "image") {
      void sendImage({ url: upgradeImageUrl(info.srcUrl), ...meta });
      return;
    }
    if (tab?.id === void 0) return;
    chrome.scripting.executeScript({ target: { tabId: tab.id, ...info.frameId ? { frameIds: [info.frameId] } : {} }, func: largestVisibleImage }).then((res) => {
      const url = res[0]?.result;
      if (url) void sendImage({ url: upgradeImageUrl(url), ...meta });
      else void chrome.action.setBadgeText({ text: "?" });
    }).catch(() => void chrome.action.setBadgeText({ text: "!" }));
  });
  async function sendImage(payload) {
    const last = [...appPorts.entries()].at(-1);
    if (!last) {
      await chrome.storage.local.set({ pendingImage: { ...payload, at: Date.now() } });
      await chrome.action.setBadgeText({ text: "1" });
      return { delivered: false };
    }
    const [tabId, port] = last;
    port.postMessage({ id: crypto.randomUUID(), kind: "image-pick", payload });
    const t = await chrome.tabs.update(tabId, { active: true });
    if (t?.windowId !== void 0) await chrome.windows.update(t.windowId, { focused: true });
    return { delivered: true };
  }
  async function deliverPendingImage(port) {
    const { pendingImage } = await chrome.storage.local.get("pendingImage");
    if (!pendingImage) return;
    await chrome.storage.local.remove("pendingImage");
    await chrome.action.setBadgeText({ text: "" });
    if (Date.now() - pendingImage.at > 30 * 6e4) return;
    const { at: _at, ...payload } = pendingImage;
    port.postMessage({ id: crypto.randomUUID(), kind: "image-pick", payload });
  }
  async function importUrl(url) {
    const last = [...appPorts.entries()].at(-1);
    if (last) {
      const [tabId, port] = last;
      port.postMessage({ id: crypto.randomUUID(), kind: "import-request", payload: { url } });
      const tab = await chrome.tabs.update(tabId, { active: true });
      if (tab?.windowId !== void 0) await chrome.windows.update(tab.windowId, { focused: true });
      return { delivered: true };
    }
    const { appUrl } = await getSettings();
    const target = new URL(appUrl);
    target.hash = `/import?url=${encodeURIComponent(url)}`;
    await chrome.tabs.create({ url: target.toString() });
    return { delivered: false };
  }
  async function registerApp(appUrl) {
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [BRIDGE_SCRIPT_ID] });
    if (existing.length) await chrome.scripting.unregisterContentScripts({ ids: [BRIDGE_SCRIPT_ID] });
    if (isLocalhost(appUrl)) return { ok: true };
    await chrome.scripting.registerContentScripts([{ id: BRIDGE_SCRIPT_ID, matches: [originPattern(appUrl)], js: ["bridge.js"], runAt: "document_start", persistAcrossSessions: true }]);
    return { ok: true };
  }
  async function foundryState() {
    const { foundryUrls } = await getSettings();
    return Promise.all(foundryUrls.map(async (url) => ({ url, granted: await chrome.permissions.contains({ origins: [originPattern(url)] }) })));
  }
  async function registerFoundry() {
    const granted = (await foundryState()).filter((f) => f.granted).map((f) => originPattern(f.url));
    const ids = Object.values(FOUNDRY_SCRIPT_IDS);
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids });
    if (existing.length) await chrome.scripting.unregisterContentScripts({ ids: existing.map((s) => s.id) });
    if (granted.length) {
      await chrome.scripting.registerContentScripts([
        { id: FOUNDRY_SCRIPT_IDS.isolated, matches: granted, js: ["foundry.js"], runAt: "document_idle", persistAcrossSessions: true },
        { id: FOUNDRY_SCRIPT_IDS.main, matches: granted, js: ["foundry-page.js"], runAt: "document_idle", world: "MAIN", persistAcrossSessions: true }
      ]);
    }
    return { ok: true, urls: granted };
  }
  chrome.runtime.onInstalled.addListener(() => void registerFoundry());
  chrome.permissions.onAdded.addListener(() => void registerFoundry());
  chrome.permissions.onRemoved.addListener(() => void registerFoundry());
})();
